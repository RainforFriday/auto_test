import os
import sys
import numpy
import time
from aicintf.uart import *
from aicintf.com import *
from aicbasic.AIC_C_CODE_LOG import *

degree_sign = u"\N{DEGREE SIGN}"

def uart_open(comport):
    global UARTc
    UARTc = Uart(comport)
    UARTc.open()
    return UARTc


def uart_close():
    UARTc.close()


class MSADC:
    def __init__(self, clk_div=40, acc_mode=1, adc_id=0):
        self.Mult = 1.0
        self.ClkDiv = clk_div
        if acc_mode == 0:
            self.Window = 256
            self.Denom = 8256
        elif acc_mode == 1:
            self.Window = 512
            self.Denom = 32896
        elif acc_mode == 2:
            self.Window = 1024
            self.Denom = 131328
        elif acc_mode == 3:
            self.Window = 4032
            self.Denom = 2033136
        else:
            raise "'acc_mode' is out of range"
        self.clkdivAddr = "40100038"
        self.vddSenAddr = "70001004"
        if adc_id == 0:  # pmu
            self.msAddr = "4010d004"
            self.winAddr = "4010d008"
            self.anaAddr = "4010d00c"
            self.roAddr = "4010d010"
        else:  # rf
            self.msAddr = "4010E004"
            self.winAddr = "4010E008"
            self.anaAddr = "4010E00C"
            self.roAddr = "4010E010"

    def basiconfig(self):
        UARTc.write_reg_mask(self.clkdivAddr, ["8", "7:0"], [1, self.ClkDiv])
        UARTc.write_reg_mask(self.winAddr, "27:16", self.Window)
        UARTc.write_reg_mask(self.anaAddr, ["28:21", "18:12", "1"], [int('01010000', 2), int('1101010', 2), 0])

    def adconfig(self):
        UARTc.write_reg_mask(self.anaAddr, ["20", "19", "10", "9:2"], [0, 1, 1, int('79', 16)],
                             "ts_mode/adc_ff_en/sdm_mode/others")

    def tsconfig(self):
        UARTc.write_reg_mask(self.anaAddr, ["20", "19", "10", "9:2"], [1, 0, 0, int('8C', 16)],
                             "ts_mode/adc_ff_en/sdm_mode/others")

    def set_diff_mode(self):
        # mode 2
        UARTc.write_reg_mask(self.winAddr, "28", 1)
        UARTc.write_reg_mask(self.anaAddr, ["11", "0"], [0, 0])

    def set_se_p_mode(self):
        # single-ended positive port input
        UARTc.write_reg_mask(self.winAddr, "28", 0)
        UARTc.write_reg_mask(self.anaAddr, ["11", "0"], [0, 1])

    def set_se_n_mode(self):
        # single-ended positive port input
        UARTc.write_reg_mask(self.winAddr, "28", 0)
        UARTc.write_reg_mask(self.anaAddr, ["11", "0"], [0, 0])

    def set_selfcal_mode(self):
        # mode 3
        UARTc.write_reg_mask(self.winAddr, "28", 1)
        UARTc.write_reg_mask(self.anaAddr, ["11", "0"], [1, 0])

    def self_calibration(self):
        self.basiconfig()
        self.adconfig()
        self.set_selfcal_mode()
        adc_ro = self.measure()
        return (int(adc_ro.split('x')[1], 16) / self.Denom - 1) * 1214 * self.Mult

    def input_sel_avdd33(self):  # mode 0
        UARTc.write_reg_mask(self.vddSenAddr, "15", 1)
        UARTc.write_reg_mask(self.vddSenAddr, "13:10", 3)
        UARTc.write_reg_mask(self.winAddr, "3:0", 15)
        self.set_diff_mode()
        self.Mult = 4.0

    def input_sel_avdd18(self):
        UARTc.write_reg_mask(self.vddSenAddr, "15", 1)
        UARTc.write_reg_mask(self.vddSenAddr, "13:10", 2)
        UARTc.write_reg_mask(self.winAddr, "3:0", 15)
        self.set_diff_mode()
        self.Mult = 2.0

    def input_sel_avdd13(self):
        UARTc.write_reg_mask(self.vddSenAddr, "15", 1)
        UARTc.write_reg_mask(self.vddSenAddr, "13:10", 1)
        UARTc.write_reg_mask(self.winAddr, "3:0", 15)
        self.set_diff_mode()
        self.Mult = 4.0 / 3.0

    def input_sel_vbat(self):
        UARTc.write_reg_mask(self.vddSenAddr, "13:10", 8)
        UARTc.write_reg_mask(self.winAddr, "3:0", 15)
        self.set_diff_mode()
        self.Mult = 5.5

    def input_sel_vtrc0(self):
        UARTc.write_reg_mask(self.vddSenAddr, "13:10", 4)
        UARTc.write_reg_mask(self.winAddr, "3:0", 15)
        self.set_diff_mode()
        self.Mult = 1.0

    def input_sel_vrefulpbuf(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 10)
        self.set_se_p_mode()
        self.Mult = 1.0

    def input_sel_vcore(self):
        UARTc.write_reg_mask(self.winAddr, ["28", "3:0"], [0, 11])
        UARTc.write_reg_mask(self.anaAddr, ["11", "0"], [0, 1])
        self.set_se_p_mode()
        self.Mult = 1.0

    def input_sel_gpio23_diff(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 2)
        self.set_diff_mode()
        self.Mult = 1.0

    def input_sel_gpio01_diff(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 3)
        self.set_diff_mode()
        self.Mult = 1.0

    def input_sel_gpio3(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 2)
        self.set_se_n_mode()
        self.Mult = 1.0

    def input_sel_gpio2(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 2)
        self.set_se_p_mode()
        self.Mult = 1.0

    def input_sel_gpio1(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 3)
        self.set_se_n_mode()
        self.Mult = 1.0

    def input_sel_gpio0(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 3)
        self.set_se_p_mode()
        self.Mult = 1.0

    def input_sel_ts_pa(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 1)
        self.set_diff_mode()
        self.Mult = 1.0

    def input_sel_testport(self):
        UARTc.write_reg_mask(self.winAddr, "3:0", 0)
        self.set_se_p_mode()
        self.Mult = 1.0

    def vddsense_off(self):
        UARTc.write_reg_mask(self.vddSenAddr, "13:10", 0)
        self.Mult = 1

    def measure(self):
        UARTc.write_reg_mask(self.msAddr, "0", 1)  # start
        sleep_time = self.ClkDiv * 25E-9 * self.Window * 1.1
        time.sleep(sleep_time)
        return UARTc.read_reg(self.roAddr)

    def ms_volt(self):
        adc_ro = self.measure()
        # return unit V
        return (int(adc_ro.split('x')[1], 16) / self.Denom - 1) * 1214 * self.Mult / 1000.0

    # measure examples
    def ms_temp_sense0(self):
        self.basiconfig()
        self.tsconfig()
        adc_ro = self.measure()
        if self.Window == 256:
            coeff = 0.04
        elif self.Window == 512:
            coeff = 0.01
        elif self.Window == 1024:
            coeff = 0.00251
        else:
            coeff = 0.000162
        temp = coeff * int(adc_ro.split('x')[1], 16) - 283
        return temp

    def ms_ts_conti(self, num=16):
        self.basiconfig()
        self.tsconfig()
        temp   = []
        if self.Window == 256:
            coeff = 0.04
        elif self.Window == 512:
            coeff = 0.01
        elif self.Window == 1024:
            coeff = 0.00251
        else:
            coeff = 0.000162
        for i in range(0, num):
            ro     = self.measure()
            value  = int(ro.split('x')[1], 16)
            temp_i = coeff * value - 283
            print("Temp  : {:4.0f} ".format(temp_i) + degree_sign + "C")
            temp.append(temp_i)
        return temp

    def ms_vbat(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_vbat()
        v_vbat = self.ms_volt()
        self.vddsense_off()
        return v_vbat * 1000.0

    def ms_avdd33(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_avdd33()
        v_avdd33 = self.ms_volt()
        self.vddsense_off()
        return v_avdd33 * 1000.0

    def ms_avdd18(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_avdd18()
        v_avdd18 = self.ms_volt()
        self.vddsense_off()
        return v_avdd18 * 1000.0

    def ms_avdd13(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_avdd13()
        v_avdd13 = self.ms_volt()
        self.vddsense_off()
        return v_avdd13 * 1000.0

    def ms_vrtc0(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_vtrc0()
        v_vrtc0 = self.ms_volt()
        self.vddsense_off()
        return v_vrtc0 * 1000.0

    def ms_vrefulpbuf(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_vrefulpbuf()
        v_vrefulpbuf = self.ms_volt()
        return v_vrefulpbuf * 1000.0

    def ms_vcore(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_vcore()
        v_vcore = self.ms_volt()
        return v_vcore * 1000.0

    def ms_gpio23_diff(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_gpio23_diff()
        v_vcore = self.ms_volt()
        return v_vcore * 1000.0

    def ms_gpio3(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_gpio3()
        v_vcore = self.ms_volt()
        return v_vcore * 1000.0

    def ms_gpio2(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_gpio2()
        v_vcore = self.ms_volt()
        return v_vcore * 1000.0

    def ms_portdc(self):
        self.basiconfig()
        self.adconfig()
        self.input_sel_testport()
        v_portdc = self.ms_volt()
        return v_portdc * 1000.0

    def ms_dc_wfadc0(self):
        UARTc.write_reg_mask("40344028", "16", 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        vreg_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        vref_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40344028", "16", 0)  # enable
        return [vreg_wfadc, vref_wfadc]

    def ms_dc_wfadc1(self):
        UARTc.write_reg_mask("40344028", "15", 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        vreg_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        vref_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40344028", "15", 0)  # enable
        return [vreg_wfadc, vref_wfadc]

    def cal_dc_wfadc0(self):
        UARTc.write_reg_mask("40344028", "16", 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        UARTc.write_reg_mask("40344154", "3:0", 8)  # adc0_vreg_vbit
        msb_vreg = 3
        for i in range(4):
            vreg_wfadc = self.ms_portdc()
            if vreg_wfadc > 960:
                UARTc.write_reg_mask("40344154", str(msb_vreg - i), 0)  # adc0_vreg_vbit
            if i < 3:
                UARTc.write_reg_mask("40344154", str(msb_vreg - 1 - i), 1)  # adc0_vreg_vbit
        vreg_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        UARTc.write_reg_mask("40344158", "19:15", 16)  # adc0_vref_vbit
        msb_vref = 19
        for i in range(5):
            vref_wfadc = self.ms_portdc()
            if vref_wfadc > 960:
                UARTc.write_reg_mask("40344158", str(msb_vref - i), 0)  # adc0_vref_vbit
            if i < 4:
                UARTc.write_reg_mask("40344158", str(msb_vref - 1 - i), 1)  # adc0_vref_vbit
        vref_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40344028", "16", 0)  # enable
        return [vreg_wfadc, vref_wfadc]

    def cal_dc_wfadc1(self):
        UARTc.write_reg_mask("40344028", "15", 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        UARTc.write_reg_mask("4034415c", "21:18", 8)  # adc1_vreg_vbit
        msb_vreg = 21
        for i in range(4):
            vreg_wfadc = self.ms_portdc()
            if vreg_wfadc > 960:
                UARTc.write_reg_mask("4034415c", str(msb_vreg - i), 0)  # adc1_vreg_vbit
            if i < 3:
                UARTc.write_reg_mask("4034415c", str(msb_vreg - 1 - i), 1)  # adc1_vreg_vbit
        vreg_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        UARTc.write_reg_mask("4034415c", "5:1", 16)  # adc1_vref_vbit
        msb_vref = 5
        for i in range(5):
            vref_wfadc = self.ms_portdc()
            if vref_wfadc > 960:
                UARTc.write_reg_mask("4034415c", str(msb_vref - i), 0)  # adc1_vref_vbit
            if i < 4:
                UARTc.write_reg_mask("4034415c", str(msb_vref - 1 - i), 1)  # adc1_vref_vbit
        vref_wfadc = self.ms_portdc()
        UARTc.write_reg_mask("40344028", "15", 0)  # enable
        return [vreg_wfadc, vref_wfadc]

    def ms_dc_btadc(self):
        UARTc.write_reg_mask("40622008", "13", 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        UARTc.write_reg_mask("40622024", " 7: 4", 8)  # adc1_vreg_vbit
        vreg_btadc = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        UARTc.write_reg_mask("40622028", "23:19", 16)  # adc1_vref_vbit
        vref_btadc = self.ms_portdc()
        UARTc.write_reg_mask("40622008", "13", 0)  # enable
        return [vreg_btadc, vref_btadc]

    def cal_dc_btadc(self):
        UARTc.write_reg_mask("40622008", "13", 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        UARTc.write_reg_mask("40622024", " 7: 4", 8)  # adc1_vreg_vbit
        msb_vreg = 7
        for i in range(4):
            vreg_btadc = self.ms_portdc()
            if vreg_btadc > 960:
                UARTc.write_reg_mask("40622024", str(msb_vreg - i), 0)  # adc1_vreg_vbit
            if i < 3:
                UARTc.write_reg_mask("40622024", str(msb_vreg - 1 - i), 1)  # adc1_vreg_vbit
        vreg_btadc = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        UARTc.write_reg_mask("40622028", "23:19", 16)  # adc1_vref_vbit
        msb_vref = 23
        for i in range(5):
            vref_btadc = self.ms_portdc()
            if vref_btadc > 960:
                UARTc.write_reg_mask("40622028", str(msb_vref - i), 0)  # adc1_vref_vbit
            if i < 4:
                UARTc.write_reg_mask("40622028", str(msb_vref - 1 - i), 1)  # adc1_vref_vbit
        vref_btadc = self.ms_portdc()
        UARTc.write_reg_mask("40622008", "13", 0)  # enable
        return [vreg_btadc, vref_btadc]

    def ms_hb_pa(self, teblkaddr, tebitaddr):
        UARTc.write_reg_mask(teblkaddr, tebitaddr, 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 3)  # test_bit
        vl   = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 4)  # test_bit
        vm_t = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 5)  # test_bit
        vh_t = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 6)  # test_bit
        bg_1v = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 7)  # test_bit
        vsw   = self.ms_portdc()
        UARTc.write_reg_mask("40502018", " 8: 7", 1)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 7)  # test_bit
        v13_t = self.ms_portdc()
        UARTc.write_reg_mask("40502018", " 8: 7", 3)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        loftout_diff = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        vl_os = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 2)  # test_bit
        isense_diff = self.ms_portdc()
        UARTc.write_reg_mask(teblkaddr, tebitaddr, 0)  # enable
        return [vl, vm_t*2, vh_t*3, vsw, -v13_t*2, loftout_diff, vl_os, isense_diff]

    def ms_hb_padrv(self, teblkaddr, tebitaddr):
        UARTc.write_reg_mask(teblkaddr, tebitaddr, 1)  # enable
        UARTc.write_reg_mask("40502018", " 8: 7", 2)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 2)  # test_bit
        vl   = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        vm_t = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 0)  # test_bit
        vh_t = self.ms_portdc()
        UARTc.write_reg_mask("40502018", " 8: 7", 1)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 1)  # test_bit
        vsw = self.ms_portdc()
        UARTc.write_reg_mask("40502018", "17:15", 2)  # test_bit
        bg_1v = self.ms_portdc()
        UARTc.write_reg_mask("40502018", " 8: 7", 3)  # test_mode
        UARTc.write_reg_mask("40502018", "17:15", 3)  # test_bit
        vl_os = self.ms_portdc()
        UARTc.write_reg_mask(teblkaddr, tebitaddr, 0)  # enable
        return [vl, vm_t*2, vh_t*3, -vsw, vl_os]

    def set_pa_vmode(self):
        UARTc.write_reg_mask("4034406c", "22:20", 1)  # hb0_pa_vl_iv_it_mode
        UARTc.write_reg_mask("4034406c", "19:17", 3)  # hb0_pa_vl_v_diode_en
        UARTc.write_reg_mask("4034406c",     "1", 0)  # hb0_pa_vl_sel_imode
        UARTc.write_reg_mask("403440dc",   "2:0", 1)  # hb1_pa_vl_iv_it_mode
        UARTc.write_reg_mask("403440e0", "31:29", 3)  # hb1_pa_vl_v_diode_en
        UARTc.write_reg_mask("403440e0",    "13", 0)  # hb1_pa_vl_sel_imode

    def set_padrv_vmode(self):
        UARTc.write_reg_mask("4034405c", "22:20", 1)  # hb0_padrv_vl_iv_it_mode
        UARTc.write_reg_mask("4034405c", "19:17", 4)  # hb0_padrv_vl_v_diode_en
        UARTc.write_reg_mask("4034405c", "1", 0)  # hb0_padrv_vl_sel_imode
        UARTc.write_reg_mask("403440cc",   "2:0", 1)  # hb1_padrv_vl_iv_it_mode
        UARTc.write_reg_mask("403440d0", "31:29", 4)  # hb1_padrv_vl_v_diode_en
        UARTc.write_reg_mask("403440d0",    "13", 0)  # hb1_padrv_vl_sel_imode

    def set_pa_imode(self):
        UARTc.write_reg_mask("40344068", " 2: 0", 0)  # hb0_pa_vl_i_itbg_bit
        UARTc.write_reg_mask("4034406c", "31:29", 5)  # hb0_pa_vl_i_itcgm_bit  <<+
        UARTc.write_reg_mask("4034406c", "22:20", 1)  # hb0_pa_vl_iv_it_mode   << top mode
        UARTc.write_reg_mask("4034406c", "19:17", 6)  # hb0_pa_vl_iv_ibvtr_bit <<-
        UARTc.write_reg_mask("4034406c", "16:14", 0)  # hb0_pa_vl_iv_ibbg_bit
        UARTc.write_reg_mask("4034406c", " 4: 2", 4)  # hb0_pa_vl_iv_ib_mode   << bot mode
        ## HB 1
        UARTc.write_reg_mask("403440dc", "14:12", 0)  # hb1_pa_vl_i_itbg_bit
        UARTc.write_reg_mask("403440dc", "11: 9", 5)  # hb1_pa_vl_i_itcgm_bit  <<+
        UARTc.write_reg_mask("403440dc",   "2:0", 1)  # hb1_pa_vl_iv_it_mode   << top mode
        UARTc.write_reg_mask("403440e0", "31:29", 6)  # hb1_pa_vl_iv_ibvtr_bit <<-
        UARTc.write_reg_mask("403440e0", "28:26", 0)  # hb1_pa_vl_iv_ibbg_bit
        UARTc.write_reg_mask("403440e0", "16:14", 4)  # hb1_pa_vl_iv_ib_mode   << bot mode

    def set_padrv_imode(self):
        UARTc.write_reg_mask("40344058", " 2: 0", 0)  # hb0_padrv_vl_i_itbg_bit
        UARTc.write_reg_mask("4034405c", "31:29", 4)  # hb0_padrv_vl_i_itcgm_bit
        UARTc.write_reg_mask("4034405c", "22:20", 1)  # hb0_padrv_vl_iv_it_mode
        UARTc.write_reg_mask("4034405c", "19:17", 4)  # hb0_padrv_vl_iv_ibvtr_bit
        UARTc.write_reg_mask("4034405c", "16:14", 0)  # hb0_padrv_vl_iv_ibbg_bit
        UARTc.write_reg_mask("4034405c", " 4: 2", 4)  # hb0_padrv_vl_iv_ib_mode
        ## HB 1
        UARTc.write_reg_mask("403440cc", "14:12", 0)  # hb1_padrv_vl_i_itbg_bit
        UARTc.write_reg_mask("403440cc", "11: 9", 4)  # hb1_padrv_vl_i_itcgm_bit
        UARTc.write_reg_mask("403440cc", "2:0", 1)  # hb1_padrv_vl_iv_it_mode
        UARTc.write_reg_mask("403440d0", "31:29", 4)  # hb1_padrv_vl_iv_ibvtr_bit
        UARTc.write_reg_mask("403440d0", "28:26", 0)  # hb1_padrv_vl_iv_ibbg_bit
        UARTc.write_reg_mask("403440d0", "16:14", 4)  # hb1_padrv_vl_iv_ib_mode

if __name__ == "__main__":

    UARTc = uart_open(20)
    UARTc.write_reg_mask("4058001C", "31: 0", 0)  # de-bug of bt-pa
    UARTc.write_reg_mask("40622000", " 3: 2", 3)  # de-bug of bt-pa

    msadc0 = MSADC(clk_div=40, acc_mode=1, adc_id=0)


    # vcore  = msadc0.ms_vcore()
    # avdd18 = msadc0.ms_avdd18()
    # avdd13 = msadc0.ms_avdd13()
    # print("vcore  : {:6.1f} mV".format(vcore))
    # print("avdd13 : {:6.1f} mV".format(avdd13))
    # print("avdd18 : {:6.1f} mV".format(avdd18))

    # UARTc.write_reg_mask("40344068", "13:10", 0)  # hb0_pa_vl_vtr_tc_bit
    # UARTc.write_reg_mask("403440dc", "25:22", 0)  # hb1_pa_vl_vtr_tc_bit

    # UARTc.write_reg_mask("40344068", "30:27", 6)  # hb0_pa_vm_cgm_ibit
    # UARTc.write_reg_mask("403440d8", "10: 7", 6)  # hb1_pa_vm_cgm_ibit

    # msadc0.set_pa_imode()
    # msadc0.set_padrv_imode()

    # msadc0.set_pa_vmode()
    # msadc0.set_padrv_vmode()

    # UARTc.write_reg_mask("4034406c", "22:20", 1)  # hb0_pa_vl_iv_it_mode
    # UARTc.write_reg_mask("4034406c", "19:17", 3)  # hb0_pa_vl_v_diode_en
    # UARTc.write_reg_mask("4034406c", "1", 0)  # hb0_pa_vl_sel_imode
    #
    # UARTc.write_reg_mask("403440dc", "2:0", 1)  # hb1_pa_vl_iv_it_mode
    # UARTc.write_reg_mask("403440e0", "31:29", 3)  # hb1_pa_vl_v_diode_en
    # UARTc.write_reg_mask("403440e0", "13", 0)  # hb1_pa_vl_sel_imode


    # [vreg_adc0, vref_adc0] = msadc1.ms_dc_wfadc0()
    # [vreg_adc1, vref_adc1] = msadc1.ms_dc_wfadc1()
    # [vreg_adc0_cal, vref_adc0_cal] = msadc1.cal_dc_wfadc0()
    # [vreg_adc1_cal, vref_adc1_cal] = msadc1.cal_dc_wfadc1()
    # print("vref_adc0  : {:>6.1f} | {:>6.1f} mV".format(vref_adc0, vref_adc0_cal))
    # print("vref_adc1  : {:>6.1f} | {:>6.1f} mV".format(vref_adc1, vref_adc1_cal))
    # print("vreg_adc0  : {:>6.1f} | {:>6.1f} mV".format(vreg_adc0, vreg_adc0_cal))
    # print("vreg_adc1  : {:>6.1f} | {:>6.1f} mV".format(vreg_adc1, vreg_adc1_cal))
    #
    # UARTc.write_reg_mask("40622000", "17:14", 15)  # pu bt_adc
    # UARTc.write_reg_mask("40622004", "7:6", 3)  # pu_iref
    # UARTc.write_reg_mask("40622024", "19", 0)  # bt_adc_core_en
    # [vreg_btadc_cal, vref_btadc_cal] = msadc1.cal_dc_btadc()
    # print("vreg_btadc : {:>6.1f} mV".format(vreg_btadc_cal))
    # print("vref_btadc : {:>6.1f} mV".format(vref_btadc_cal))


    msadc1 = MSADC(clk_div=80, acc_mode=1, adc_id=1)
    # msadc1.ms_ts_conti(255)
    Temp   = msadc1.ms_temp_sense0()
    print("---- TX ## Temp: {:>6.1f} ".format(Temp) + degree_sign + "C----")

    UARTc.write_reg_mask("40344000", "21:18", 15)  # pu_hb0_pa/padrv =1
    UARTc.write_reg_mask("40344000", "15:14",  2)  # hb0_pa_gain_dr=1, _en=0
    # # UARTc.write_reg_mask("403441a4", "23:20", int('1110',2))  # ant0_txon_dr=1
    [hb0_pa_vl, hb0_pa_vm, hb0_pa_vh, hb0_pa_vsw, hb0_pa_v13, hb0_pa_loftout_diff, hb0_pa_vl_os, hb0_pa_isense_diff] = msadc1.ms_hb_pa("40344024", "26")
    [hb0_padrv_vl, hb0_padrv_vm, hb0_padrv_vh, hb0_padrv_vsw, hb0_padrv_vl_os] = msadc1.ms_hb_padrv("40344024", "27")
    # # UARTc.write_reg_mask("403441a4", "23:20", 0)  # ant0_txon_dr=0
    UARTc.write_reg_mask("40344000", "21:18", 0)  # pu_hb0_pa/padrv_dr =0
    UARTc.write_reg_mask("40344000", "15:14", 0)  # hb0_pa_gain_dr=0

    UARTc.write_reg_mask("40344008", "15:12", 15)  # pu_hb1_pa/padrv =1
    UARTc.write_reg_mask("40344008", " 9: 8",  2)  # hb1_pa_gain_dr=1, _en=0
    # # UARTc.write_reg_mask("403441a8", "23:20", int('1110',2))  # ant1_txon_dr=1
    [hb1_pa_vl, hb1_pa_vm, hb1_pa_vh, hb1_pa_vsw, hb1_pa_v13, hb1_pa_loftout_diff, hb1_pa_vl_os, hb1_pa_isense_diff] = msadc1.ms_hb_pa("40344024", "9")
    [hb1_padrv_vl, hb1_padrv_vm, hb1_padrv_vh, hb1_padrv_vsw, hb1_padrv_vl_os] = msadc1.ms_hb_padrv("40344024", "10")
    # # UARTc.write_reg_mask("403441a8", "23:20", 0)  # ant1_txon_dr=0
    UARTc.write_reg_mask("40344008", "15:12", 0)  # pu_hb1_pa/padrv_dr =0
    UARTc.write_reg_mask("40344008", " 9: 8", 0)  # hb1_pa_gain_dr=0

    print("          HB0_PADRV | HB0_PA | HB1_PA | HB1_PADRV")
    print("VH   /mV:  {:>6.1f}   | {:>6.1f} | {:>6.1f} | {:>6.1f}".format(hb0_padrv_vh   , hb0_pa_vh   , hb1_pa_vh   , hb1_padrv_vh   ))
    print("VM   /mV:  {:>6.1f}   | {:>6.1f} | {:>6.1f} | {:>6.1f}".format(hb0_padrv_vm   , hb0_pa_vm   , hb1_pa_vm   , hb1_padrv_vm   ))
    print("VL   /mV:  {:>6.1f}   | {:>6.1f} | {:>6.1f} | {:>6.1f}".format(hb0_padrv_vl   , hb0_pa_vl   , hb1_pa_vl   , hb1_padrv_vl   ))
    print("VLos /mV:  {:>6.1f}   | {:>6.1f} | {:>6.1f} | {:>6.1f}".format(hb0_padrv_vl_os, hb0_pa_vl_os, hb1_pa_vl_os, hb1_padrv_vl_os))
    print("Vsw  /mV:  {:>6.1f}   | {:>6.1f} | {:>6.1f} | {:>6.1f}".format(hb0_padrv_vsw  , hb0_pa_vsw  , hb1_pa_vsw  , hb1_padrv_vsw  ))
    print("V13  /mV:             {:>6.1f} | {:>6.1f}".format(hb0_pa_v13, hb1_pa_v13))
    # print("isen /mV:             {:>6.1f} | {:>6.1f}".format(hb0_pa_isense_diff, hb1_pa_isense_diff))

    Temp = msadc1.ms_temp_sense0()
    print("---- TX ## Temp: {:>6.1f} C ----".format(Temp))
    uart_close()
