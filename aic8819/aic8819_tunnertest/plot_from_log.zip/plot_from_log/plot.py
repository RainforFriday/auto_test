
import pandas as pd
import matplotlib.pyplot as plt



import re
from collections import defaultdict

def extract_dpd_data(log_text):
    # 初始化存储结构
    data = defaultdict(list)
    current_am_type = None
    block_count = defaultdict(int)

    # 正则表达式匹配数据行
    pattern = re.compile(r'^\s*(\d+)\s+(\d+)\s+(\d+)\s*$')

    # 按行处理日志
    for line in log_text.split('\n'):
        line = line.strip()
        if line.startswith('cal'):
            # 检测到新数据块，提取am类型（如7、9、b、d）
            am_type = line.split()[1]
            current_am_type = f'am{am_type}'
            block_count[current_am_type] += 1
        elif pattern.match(line):
            # 提取am_begin和am_back
            am_begin, am_back, _ = map(int, pattern.match(line).groups())
            # 根据出现次数决定标签（amX或amX_2）
            label = current_am_type if block_count[current_am_type] == 1 else f'{current_am_type}_2'
            data[label].append((am_begin, am_back))

    return data

file_path = "8819_dpd.log"  # 替换为你的文件路径




# 示例日志文本
log_text = """
cal 7 index
runPaResCore
 est tx start =  682, est rx start =  715, dly = 33, total seg = 5, 
am_begin      am_back        ph      *10000
       629     546603          0
       947     822810          0
      1269    1129972          0
      1611    1485651      11265
      1811    1739516       5871
      2041    2002832      15764
      2299    2321098      13896
      2441    2546192      12912
      2592    2773632      19655
"""

# 提取数据
extracted_data = extract_dpd_data(log_text)

# 打印结果
for label, points in extracted_data.items():
    x = [point[0] for point in points]
    y = [point[1] for point in points]
    print(f"{label}: x={x}, y={y}")












# 1. 读取 Excel 文件
file_path = "amam.xlsx"  # 替换为你的文件路径
df = pd.read_excel(file_path)

# 2. 设置第一列为 x 轴，其他列为 y 轴
x = df.iloc[:, 0]  # 第一列作为 x 轴
y_columns = df.columns[1:]  # 其他列作为 y 轴

# 3. 绘制折线图
plt.figure(figsize=(12, 6))  # 设置图像大小

for column in y_columns:
    plt.plot(x, df[column], label=column)  # 绘制每条折线

# 4. 添加图例和标签
plt.xlabel(df.columns[0])  # x 轴标签（第一列名称）
plt.ylabel("Value")        # y 轴标签
plt.title("Multi-Line Chart from Excel Data")  # 图表标题
plt.legend()              # 显示图例
plt.grid(True)            # 显示网格

# 5. 显示图表
plt.show()

